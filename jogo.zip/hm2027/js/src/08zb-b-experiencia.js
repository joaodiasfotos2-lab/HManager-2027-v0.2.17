// =================================================================
// Equipa B como campo de rodagem (2026-10-14)
// =================================================================
// Pedido do João: "os clubes aproveitam a equipa B para dar experiência sénior aos sub-19 e para
// rodar alguns da equipa A, quando vem de lesão" e, a seguir, "quero que a B e os sub-19 sejam a
// mesma". Resultado: nos clubes com equipa B o escalão Sub-19 da academia deixou de existir (a B é
// o Sub-19; ver academyHasB/runAcademyAnnualIntake, 08b-academia-juvenis.js), por isso já não há
// "chamar sub-19 à B" — os jovens já estão no plantel da B. Aqui fica só a rodagem:
//
//  Rodagem após lesão: até BX_MAX_RODAGEM jogadores da equipa A que acabaram de ter alta
//  (p.readapt, 08w-lesoes.js) jogam pela B em vez da A nesse dia (a A e a B jogam sempre no mesmo
//  dia): ficam indisponíveis para a A até ao fim do dia (p.bxJogouB, playerAvailableForMatch) e
//  só se a A ainda não jogou hoje. Quem joga encurta a readaptação (-25% dos dias), mas arrisca a
//  recaída no jogo (o risco de recaída normal da readaptação aplica-se também aí).
//
// Mecânica: ensureMinimumSquad (09-fluxo-epoca.js) chama bxReforcosParaB(equipaB, added) antes de
// qualquer jogo — os chamados entram no plantel da B só para o jogo e regressam em
// removeProvisionalPlayers (mesmo circuito do empréstimo de emergência entre A e B, 2026-10-03).
// O utilizador controla o seu clube em Clube › Academia (uma caixa, por omissão desligada); a IA usa-o só em parte dos casos (é boa gestão, não obrigação).
// (bxDevolverParaAcademia/bxLimparOrfaos ficam só para limpar saves feitos com a versão anterior,
// em que sub-19 da academia eram chamados à B.)

const BX_MAX_RODAGEM = 2;

function bxPolitica(clube){
  if(!clube.bxPolitica) clube.bxPolitica = { rodagem: clube.id!==state.userTeamId };
  return clube.bxPolitica;
}
function bxIdade(p){
  const a = p.dataNascimento ? computeAge(p.dataNascimento, state.currentDate) : null;
  return a!=null ? a : (p.age||0);
}
function bxDia(date){ return Math.floor(new Date(date).getTime()/86400000); }
// A equipa já disputou hoje um jogo oficial? (então os seus jogadores já jogaram: sem rodagem)
function bxJaJogouHoje(teamId){
  return Object.values(state.competitions).some(comp=>{
    if(!comp.teamIds || !comp.teamIds.includes(teamId) || !comp.fixtures) return false;
    const round = comp.fixtures[comp.currentRound];
    if(!round || !round.date || !sameDay(new Date(round.date), state.currentDate)) return false;
    return round.some(fx=>fx.played && (fx.home===teamId || fx.away===teamId));
  });
}
function bxCandidatosRodagem(parent){
  return parent.players.filter(p=>
    p.readapt && !p.__provisional && !p.__loanedForMatchFrom && !p.emprestimo &&
    playerAvailableForMatch(p) && !(p.convocadoSelecaoAte && new Date(p.convocadoSelecaoAte) > state.currentDate)
  ).sort((a,b)=>(b.readapt.dias||0)-(a.readapt.dias||0));
}
// Chamado por ensureMinimumSquad(team) — só para equipas B com jogo oficial hoje.
function bxReforcosParaB(team, added){
  const parent = team && team.equipaPrincipalId ? state.teams[team.equipaPrincipalId] : null;
  if(!parent || !teamHasFixtureToday(team.id)) return;
  const pol = bxPolitica(parent);
  if(pol.rodagem && !bxJaJogouHoje(parent.id)){
    // Boa gestão, não obrigação: na IA só alguns dos que regressam de lesão fazem rodagem (50% cada);
    // no clube do utilizador só se ele ligar a opção (por omissão desligada).
    const querRodar = p => parent.id===state.userTeamId || Math.random() < 0.5;
    bxCandidatosRodagem(parent).filter(querRodar).slice(0, BX_MAX_RODAGEM).forEach(p=>{
      parent.players = parent.players.filter(x=>x.id!==p.id);
      p.__loanedForMatchFrom = parent.id;
      p.__bxRodagem = true;
      p.__bxAntes = { jogos: (p.season&&p.season.jogos)||0 };
      p.titular = false;
      team.players.push(p); added.push(p);
    });
  }
  if(!Array.isArray(state.bxHistorico)) state.bxHistorico = [];
  const nR = added.filter(p=>p.__bxRodagem).length;
  if(nR){
    state.bxHistorico.push({ season:state.season, teamId:team.id, rodagem:nR });
    if(state.bxHistorico.length>200) state.bxHistorico.shift();
  }
}
// Depois do jogo: devolve o jovem à academia, regista a experiência e repõe os campos de clube
// que o jogo mexe (moral/satisfação/condição não existem num jovem da academia).
function bxDevolverParaAcademia(p){
  const clube = state.teams[p.__academyLoanFrom];
  const antes = p.__bxAntes || {};
  ["moral","satisfacao","condicao"].forEach(k=>{
    if(antes[k]===undefined) delete p[k]; else p[k]=antes[k];
  });
  p.diasLesao = 0; p.suspensoJogos = 0; if(p.lesaoInfo) p.lesaoInfo = null;
  delete p.__academyLoanFrom; delete p.__bxAntes;
  if(clube && clube.academy && clube.academy.brackets.sub19 && !clube.academy.brackets.sub19.players.some(x=>x.id===p.id)){
    p.academyBracket = "sub19";
    clube.academy.brackets.sub19.players.push(p);
  }
}
// Depois do jogo, para quem veio da A em rodagem: encurta a readaptação se chegou a jogar.
function bxAposRodagem(p){
  const antes = p.__bxAntes || {};
  const jogou = ((p.season&&p.season.jogos)||0) > (antes.jogos||0);
  if(jogou && p.readapt){
    p.readapt.dias = Math.max(0, p.readapt.dias - Math.ceil((p.readapt.total||4) * 0.25));
    if(p.readapt.dias <= 0) p.readapt = null;
    p.bxRodagens = (p.bxRodagens||0) + 1;
  }
  // Já esteve em campo/no banco pela B hoje: não está disponível para a A até ao fim do dia.
  p.bxJogouB = bxDia(state.currentDate);
  delete p.__bxRodagem; delete p.__bxAntes;
}
// Limpeza ao carregar um save feito a meio de um jogo.
function bxLimparOrfaos(){
  Object.values(state.teams).forEach(team=>{
    if(!team || !Array.isArray(team.players)) return;
    const ficar = [];
    team.players.forEach(p=>{
      if(p && p.__academyLoanFrom){ bxDevolverParaAcademia(p); return; }
      ficar.push(p);
    });
    team.players = ficar;
  });
}

// Painel na ficha do clube (separador Academia) — só o clube do utilizador tem a caixa.
function bxPainelHtml(team){
  if(!team.equipaBId) return "";
  const meu = team.id===state.userTeamId;
  const pol = bxPolitica(team);
  const texto = `Nos clubes com equipa B, a B é o Sub-19: quem sai do Sub-17 sobe diretamente para ela e joga a competição sénior (por isso esta academia não tem escalão Sub-19). A B pode ainda servir para dar ritmo a quem regressa de lesão (opcional, é só boa gestão — a IA fá-lo em parte dos casos e aqui só se ligares a caixa): até ${BX_MAX_RODAGEM} jogadores da equipa A que acabaram de ter alta jogam pela B (encurtam a readaptação, com o risco de recaída do costume); nesse dia ficam fora da convocatória da equipa A, que joga no mesmo dia. Só se a A ainda não jogou.`;
  const caixas = meu ? `
      <label style="display:block;margin:4px 0;"><input type="checkbox" data-bxpol="rodagem" ${pol.rodagem?"checked":""}> Rodagem na equipa B para quem regressa de lesão</label>`
    : "";
  return `<div class="pm-retro-section-lbl">Equipa B — Sub-19 e rodagem</div><p class="pm-retro-subline">${texto}</p>${caixas}`;
}
document.addEventListener("change", e=>{
  const el = e.target && e.target.closest ? e.target.closest("[data-bxpol]") : null;
  if(!el) return;
  const team = state.teams[state.userTeamId]; if(!team) return;
  bxPolitica(team)[el.getAttribute("data-bxpol")] = !!el.checked;
});
