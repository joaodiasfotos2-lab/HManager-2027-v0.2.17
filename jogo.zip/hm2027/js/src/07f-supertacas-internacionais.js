  // ======================= 07f-supertacas-internacionais.js =======================
  // Supercopa de España e Supercoppa Italiana — as "supertaças" de Espanha e Itália. Estrutural-
  // mente muito diferentes uma da outra (ver estudo, claude/HM2027_Estudo_TacasEspanhaItalia_
  // 2026-09-12.md, secção 4):
  //  - Supercopa de España: 4 clubes fixos (campeão + vice da OK Liga, vencedor + finalista da
  //    Copa del Rey, todos da época anterior), Final Four de pré-época (1ª semana de outubro,
  //    antes de a OK Liga sequer começar), campo neutro — "mini-Elite Cup" de 4 equipas, sem
  //    sorteio (o emparelhamento das meias é sempre o mesmo, ver computeSupercopaEspanaQualification).
  //  - Supercoppa Italiana: só 2 clubes (campeão da Serie A1 vs. vencedor da Coppa Italia, da
  //    época anterior), eliminatória a DUAS MÃOS (confirmado com fontes reais — ao contrário da
  //    Supertaça portuguesa, que é jogo único), em casa de cada um, a meio da época (novembro/
  //    dezembro real) — as datas ficam conhecidas logo no início da época (tal como a Elite Cup),
  //    mas só são resolvidas quando o calendário lá chega mesmo (ver processSupercoppaItalianaForCurrentDate).
  //
  // Ambas reaproveitam a mesma regra de "dobradinha" já usada pela Supertaça António Livramento
  // (07c-supertaca.js): quando o mesmo clube ocupa duas das vagas de qualificação, a vaga livre
  // passa para o classificado seguinte (confirmado com fontes reais para ambos os países — ver
  // secção 4 do estudo).
  // =================================================================
  const SUPERCOPA_ESPANA_PRIZE_WINNER = 30000;
  const SUPERCOPA_ESPANA_PRIZE_RUNNERUP = 15000;
  const SUPERCOPA_ESPANA_PRIZE_SEMIFINALIST = 5000;
  const SUPERCOPA_ESPANA_PRESTIGE_WINNER = 1.2;
  const SUPERCOPPA_ITALIANA_PRIZE_WINNER = 25000;
  const SUPERCOPPA_ITALIANA_PRIZE_RUNNERUP = 10000;
  const SUPERCOPPA_ITALIANA_PRESTIGE_WINNER = 1.0;

  // ---------------------------------------------------------------
  // Supercopa de España
  // ---------------------------------------------------------------
  // 1ª semana de outubro (sábado meias, domingo final) — duas semanas antes do início real da OK
  // Liga (getPlacardOpeningSunday usa o 2º sábado de outubro), por isso nunca colide com a liga.
  function supercopaEspanaFaseDates(season){
    const y = 2026 + (season - 1);
    const saturday = firstWeekdayOfMonth(y, 9, 6); // outubro=9, sábado=6 — 1º sábado de outubro
    return { semifinal: new Date(saturday), final: addDays(saturday, 1) };
  }
  // Apuramento real (confirmado com fontes, edição 2026): campeão e vice da OK Liga + vencedor e
  // finalista da Copa del Rey, todos da época anterior. Quando o mesmo clube ocupa duas vagas
  // (ex.: o vencedor da Copa del Rey já era também o vice-campeão da liga), a vaga livre passa
  // para o classificado seguinte da liga (regra real, confirmada — ver secção 4 do estudo).
  // Emparelhamento das meias, também confirmado com fontes reais: campeão da liga vs. finalista
  // da copa; vencedor da copa vs. vice da liga (ou quem tenha ficado a preencher essa vaga).
  function computeSupercopaEspanaQualification(summary){
    const ligaCampeao = summary && summary.okLigaChampionId || null;
    const ligaVice = summary && summary.okLigaRunnerUpId || null;
    const copaVencedor = summary && summary.copaDelReyVencedorId || null;
    const copaFinalista = summary && summary.copaDelReyFinalistaId || null;
    const standings = (summary && summary.okLigaStandingsIds) || [];
    if(!ligaCampeao || !copaVencedor) return null;
    const used = new Set([ligaCampeao, copaVencedor]);
    function resolveSeat(candidate){
      if(candidate && !used.has(candidate)){ used.add(candidate); return candidate; }
      for(const id of standings){ if(!used.has(id)){ used.add(id); return id; } }
      return null;
    }
    const ligaViceFinal = resolveSeat(ligaVice);
    const copaFinalistaFinal = resolveSeat(copaFinalista);
    if(!ligaViceFinal || !copaFinalistaFinal || ligaViceFinal===copaFinalistaFinal) return null;
    return {
      ligaCampeao, ligaVice: ligaViceFinal, copaVencedor, copaFinalista: copaFinalistaFinal,
      sf1: [ligaCampeao, copaFinalistaFinal], sf2: [copaVencedor, ligaViceFinal],
      substituicaoVagaLiga: ligaViceFinal!==ligaVice, substituicaoVagaCopa: copaFinalistaFinal!==copaFinalista,
    };
  }
  function initSupercopaEspana(options){
    options = options || {};
    if(!state.supercopaEspana || typeof state.supercopaEspana!=="object") state.supercopaEspana = { historico: [], edicao: null };
    if(!Array.isArray(state.supercopaEspana.historico)) state.supercopaEspana.historico = [];
    if(state.supercopaEspana.edicao && state.supercopaEspana.edicao.epoca===state.season) return;
    if(state.supercopaEspana.historico.some(e=>e.epoca===state.season)) return;
    let qualificacao;
    if(options.initialEditionOverride){
      // 1ª edição de sempre (sem época anterior no jogo): resultados REAIS de 2025-26 confirmados
      // com fontes — Igualada HC campeão da OK Liga, HC Liceo vencedor da Copa del Rey (também
      // vice da liga — vaga preenchida pelo FC Barcelona, 3º classificado), CP Calafell finalista
      // vencido da Copa del Rey. Semifinais reais confirmadas: Igualada-Calafell e Liceo-Barça.
      qualificacao = {
        ligaCampeao: "igualada-hc", ligaVice: "fc-barcelona", copaVencedor: "hc-liceo", copaFinalista: "cp-calafell",
        sf1: ["igualada-hc", "cp-calafell"], sf2: ["hc-liceo", "fc-barcelona"],
        substituicaoVagaLiga: true, substituicaoVagaCopa: false, origem: "primeira-edicao-real-2025-26",
      };
    } else {
      const summary = options.summary || state.pendingSeasonSummary || state.lastSeasonSummary || {};
      qualificacao = computeSupercopaEspanaQualification(summary);
      if(!qualificacao){ state.supercopaEspana.edicao = null; return; }
    }
    const ids = [qualificacao.sf1[0], qualificacao.sf1[1], qualificacao.sf2[0], qualificacao.sf2[1]];
    if(ids.some(id=>!state.teams[id])){
      console.error("Supercopa de España: clube de qualificação inexistente — edição não gerada.", qualificacao);
      state.supercopaEspana.edicao = null; return;
    }
    const datas = supercopaEspanaFaseDates(state.season);
    const edicao = {
      epoca: state.season, seasonLabel: seasonLabel(state.season), fase: "semifinal",
      qualificacao, datas,
      jogos: { semifinal: [makeCupTie(qualificacao.sf1[0], qualificacao.sf1[1]), makeCupTie(qualificacao.sf2[0], qualificacao.sf2[1])], final: [] },
      campeao: null, runnerUp: null, premiosAtribuidos: false,
    };
    // Correção (verificação pedida pelo utilizador): a Supercopa de España nunca verificava
    // colisão nenhuma com outras provas — protegida agora com a mesma proteção genérica usada em
    // todas as restantes competições, antes de atribuir a data aos próprios jogos desta fase.
    // Os quatro clubes já são conhecidos neste momento (ids) — protege-se apenas a disponibilidade
    // real desses clubes (3.3 da auditoria externa), não o dia inteiro.
    avoidLeagueCollisionsOnDate(datas.semifinal, "Supercopa de España", ids);
    edicao.jogos.semifinal.forEach(j=>{ j.date = new Date(datas.semifinal); });
    state.supercopaEspana.edicao = edicao;
    const substTxt = [qualificacao.substituicaoVagaLiga?"vice da liga":null, qualificacao.substituicaoVagaCopa?"finalista da copa":null].filter(Boolean);
    const notaSubst = substTxt.length ? ` (vaga de ${substTxt.join(" e de ")} preenchida pelo classificado seguinte da liga, por coincidência de clubes)` : "";
    pushNews(state.currentDate, `Supercopa de España ${edicao.seasonLabel}: meias-finais ${teamLinkHtml(qualificacao.sf1[0])} vs ${teamLinkHtml(qualificacao.sf1[1])} e ${teamLinkHtml(qualificacao.sf2[0])} vs ${teamLinkHtml(qualificacao.sf2[1])}, em campo neutro, a ${fmtDateLong(datas.semifinal)}${notaSubst}.`, "sistema", "Supercopa de España", {autoAdvanceStop:true});
  }
  function supercopaEspanaAwardChampion(edicao, campeaoId, runnerUpId){
    const campeaoTeam = state.teams[campeaoId], runnerUpTeam = state.teams[runnerUpId];
    edicao.campeao = campeaoId; edicao.runnerUp = runnerUpId;
    if(campeaoTeam){
      awardClubTitle(campeaoId, "supercopa-espana", `Supercopa de España ${edicao.seasonLabel}`);
      campeaoTeam.reputacaoPontos = clamp((campeaoTeam.reputacaoPontos!=null?campeaoTeam.reputacaoPontos:normalizeClubReputation(campeaoTeam.reputacao, campeaoTeam)) + SUPERCOPA_ESPANA_PRESTIGE_WINNER, 5, 99);
      campeaoTeam.reputacao = reputationFromPoints(campeaoTeam.reputacaoPontos);
      addFinanceMovement(campeaoTeam, "receita", "Prémio de competição", `Supercopa de España ${edicao.seasonLabel} — vencedor`, SUPERCOPA_ESPANA_PRIZE_WINNER, state.currentDate);
    }
    if(runnerUpTeam) addFinanceMovement(runnerUpTeam, "receita", "Prémio de competição", `Supercopa de España ${edicao.seasonLabel} — finalista`, SUPERCOPA_ESPANA_PRIZE_RUNNERUP, state.currentDate);
    (edicao.jogos.semifinal||[]).forEach(j=>{
      const loserId = tacaTieWinner(j)===j.home ? j.away : j.home;
      const team = state.teams[loserId];
      if(team) addFinanceMovement(team, "receita", "Prémio de competição", `Supercopa de España ${edicao.seasonLabel} — meia-final`, SUPERCOPA_ESPANA_PRIZE_SEMIFINALIST, state.currentDate);
    });
    edicao.premiosAtribuidos = true;
    pushNews(state.currentDate, `🏆 ${teamLinkHtml(campeaoId)} venceu a Supercopa de España ${edicao.seasonLabel}!`, "sistema", "Supercopa de España", {autoAdvanceStop:true});
  }
  function supercopaEspanaCheckFaseComplete(){
    const edicao = state.supercopaEspana && state.supercopaEspana.edicao;
    if(!edicao || edicao.fase!=="semifinal") return;
    const jogos = edicao.jogos.semifinal;
    if(!jogos.every(j=>j.played)) return;
    const winners = jogos.map(tacaTieWinner);
    // Os dois finalistas já são conhecidos neste momento — protege-se apenas a disponibilidade
    // real desses clubes (3.3 da auditoria externa), não o dia inteiro.
    avoidLeagueCollisionsOnDate(edicao.datas.final, "Supercopa de España", winners);
    edicao.jogos.final = [makeCupTie(winners[0], winners[1])];
    edicao.jogos.final[0].date = new Date(edicao.datas.final);
    edicao.fase = "final";
    pushNews(state.currentDate, `Final da Supercopa de España ${edicao.seasonLabel} definida: ${teamLinkHtml(winners[0])} vs ${teamLinkHtml(winners[1])}.`, "sistema", "Supercopa de España", {autoAdvanceStop:true});
  }
  function supercopaEspanaRecordTieResult(fase, idx, hs, as, soWinner){
    const edicao = state.supercopaEspana && state.supercopaEspana.edicao;
    const tie = edicao && edicao.jogos[fase] && edicao.jogos[fase][idx];
    if(!tie || tie.played) return;
    tie.played = true; tie.homeScore = hs; tie.awayScore = as; tie.soWinner = soWinner||null;
    const winner = tacaTieWinner(tie);
    if(!winner){ console.error("Supercopa de España: eliminatória terminou sem vencedor definido.", tie); return; }
    const loser = winner===tie.home ? tie.away : tie.home;
    // Correção (verificação pedida pelo utilizador): a meia-final nunca tinha notícia dedicada
    // nenhuma quando era o clube do utilizador a passar ou a sair — só a final (definida a seguir,
    // já com os dois nomes) e o campeão o mencionavam, implicitamente. Mesmo padrão já usado nas
    // restantes competições de eliminação direta.
    if(fase==="semifinal"){
      if(winner===state.userTeamId){
        pushNews(state.currentDate, `${teamLinkHtml(winner)} apura-se para a final da Supercopa de España ${edicao.seasonLabel}, após vencer ${teamLinkHtml(loser)}.`, "sistema", `${myTeam().name} avança na Supercopa de España`, {autoAdvanceStop:true});
      } else if(loser===state.userTeamId){
        pushNews(state.currentDate, `${teamLinkHtml(loser)} foi eliminado da Supercopa de España ${edicao.seasonLabel} na meia-final, após perder com ${teamLinkHtml(winner)}.`, "sistema", `${myTeam().name} eliminado da Supercopa de España`, {autoAdvanceStop:true});
      }
    }
    if(fase==="final"){
      supercopaEspanaAwardChampion(edicao, winner, loser);
      edicao.fase = "concluida";
      if(!state.supercopaEspana.historico.some(e=>e.epoca===edicao.epoca)) state.supercopaEspana.historico.push({ ...edicao });
      return;
    }
    supercopaEspanaCheckFaseComplete();
  }
  function processSupercopaEspanaForCurrentDate(){
    const edicao = state.supercopaEspana && state.supercopaEspana.edicao;
    if(!edicao || edicao.fase==="concluida") return false;
    let processedAny = false;
    while(true){
      const jogos = edicao.jogos[edicao.fase]||[];
      const idx = jogos.findIndex(j=>!j.played && j.date && j.date<=state.currentDate);
      if(idx<0) break;
      const tie = jogos[idx];
      const involvesUser = tie.home===state.userTeamId || tie.away===state.userTeamId;
      if(!involvesUser){
        const res = simulateMatchToCompletion(tie.home, tie.away, true, true, "supercopa-espana"); // isPlayoff/neutralVenue: sempre, na Supercopa
        supercopaEspanaRecordTieResult(edicao.fase, idx, res.home, res.away, res.soWinner);
        processedAny = true;
        if(edicao.fase==="concluida") return true;
        continue;
      }
      if(state.matchDayReady) break;
      const oppId = tie.home===state.userTeamId ? tie.away : tie.home;
      state.pendingProvisional = { mine: ensureMinimumSquad(myTeam()), opp: ensureMinimumSquad(state.teams[oppId]) };
      state.pendingFixture = tie; state.pendingSupercopaEspanaFase = edicao.fase; state.pendingSupercopaEspanaIndex = idx;
      state.pendingSuspensionServing = { home: getSuspendedIds(tie.home), away: getSuspendedIds(tie.away) };
      generatePreGameReport(tie, `Supercopa de España — ${edicao.fase==="final"?"Final":"Meia-Final"}`, null);
      state.matchDayReady = true;
      return true;
    }
    return processedAny;
  }

  // ---------------------------------------------------------------
  // Supercoppa Italiana
  // ---------------------------------------------------------------
  // Datas reais confirmadas (edição 2026-27): andata (1ª mão) última quarta-feira de novembro, em
  // casa do adversário (o clube que NÃO é o campeão nacional); ritorno (2ª mão) quarta-feira de
  // meados de dezembro, em casa do campeão nacional.
  function supercoppaItalianaLegDates(season){
    const y = 2026 + (season - 1);
    const andata = nextWeekday(new Date(y, 10, 20), 3); // quarta-feira, final de novembro
    const ritorno = nextWeekday(new Date(y, 11, 10), 3); // quarta-feira, meados de dezembro
    return { andata: new Date(andata), ritorno: new Date(ritorno) };
  }
  // Mesma regra de "dobradinha" da Supertaça (computeSupertacaQualification, 07c-supertaca.js):
  // se o campeão da Serie A1 também venceu a Coppa Italia, joga em seu lugar o finalista vencido
  // da Coppa Italia — confirmado com fontes reais (edição 2026-27: Trissino venceu as duas provas
  // em 2025-26, e a Supercoppa seguinte foi mesmo Trissino vs. Bassano, o finalista vencido).
  function computeSupercoppaItalianaQualification(summary){
    const campeaoId = summary && summary.serieA1ChampionId || null;
    const coppaVencedorId = summary && summary.coppaItaliaVencedorId || null;
    const coppaFinalistaId = summary && summary.coppaItaliaFinalistaId || null;
    if(!campeaoId || !coppaVencedorId) return null;
    let adversarioId = coppaVencedorId, substituicaoDuploVencedor = false;
    if(coppaVencedorId===campeaoId){
      adversarioId = coppaFinalistaId;
      substituicaoDuploVencedor = true;
    }
    if(!adversarioId || adversarioId===campeaoId) return null;
    return { campeaoNacionalId: campeaoId, coppaVencedorId, coppaFinalistaId, adversarioId, substituicaoDuploVencedor };
  }
  function initSupercoppaItaliana(options){
    options = options || {};
    if(!state.supercoppaItaliana || typeof state.supercoppaItaliana!=="object") state.supercoppaItaliana = { historico: [], jogo: null };
    if(!Array.isArray(state.supercoppaItaliana.historico)) state.supercoppaItaliana.historico = [];
    if(state.supercoppaItaliana.jogo && state.supercoppaItaliana.jogo.epoca===state.season) return;
    if(state.supercoppaItaliana.historico.some(e=>e.epoca===state.season)) return;
    const datas = supercoppaItalianaLegDates(state.season);
    let campeaoNacionalId, adversarioId, qualificacao;
    if(options.initialEditionOverride){
      // 1ª edição de sempre: resultados REAIS de 2025-26 confirmados com fontes — HC Trissino
      // venceu a Serie A1 e a Coppa Italia (dobradinha real); joga em seu lugar, na Supercoppa, o
      // Hockey Bassano 1954 (finalista vencido da Coppa Italia) — tal como aconteceu de facto.
      campeaoNacionalId = "trissino"; adversarioId = "bassano";
      qualificacao = { campeaoNacionalId, coppaVencedorId: "trissino", coppaFinalistaId: "bassano", adversarioId, substituicaoDuploVencedor: true, origem: "primeira-edicao-real-2025-26" };
    } else {
      const summary = options.summary || state.pendingSeasonSummary || state.lastSeasonSummary || {};
      const q = computeSupercoppaItalianaQualification(summary);
      if(!q){ state.supercoppaItaliana.jogo = null; return; }
      campeaoNacionalId = q.campeaoNacionalId; adversarioId = q.adversarioId; qualificacao = q;
    }
    if(!state.teams[campeaoNacionalId] || !state.teams[adversarioId]){
      console.error("Supercoppa Italiana: clube de qualificação inexistente — edição não gerada.", { campeaoNacionalId, adversarioId });
      state.supercoppaItaliana.jogo = null; return;
    }
    // Correção (verificação pedida pelo utilizador): a Supercoppa Italiana nunca verificava
    // colisão nenhuma com outras provas — as suas datas (final de novembro/meados de dezembro,
    // à quarta-feira) caem exatamente na mesma janela usada pela WSE Cup (oitavos/quartos) e
    // pela WSE Trophy (preliminar/quartos), ambas também à quarta-feira. Protegida agora com a
    // mesma proteção genérica usada em todas as restantes competições, antes de atribuir as
    // datas aos próprios jogos.
    // Os dois clubes já são conhecidos neste momento — protege-se apenas a disponibilidade real
    // desses clubes (3.3 da auditoria externa), não o dia inteiro.
    avoidLeagueCollisionsOnDate(datas.andata, "Supercoppa Italiana", [campeaoNacionalId, adversarioId]);
    avoidLeagueCollisionsOnDate(datas.ritorno, "Supercoppa Italiana", [campeaoNacionalId, adversarioId]);
    // Andata em casa do adversário, ritorno em casa do campeão nacional — real, não neutro (ao
    // contrário da Supertaça portuguesa e da Supercopa de España).
    state.supercoppaItaliana.jogo = {
      epoca: state.season, seasonLabel: seasonLabel(state.season), qualificacao,
      campeaoNacionalId, adversarioId, concluida: false, vencedor: null,
      leg1: { home: adversarioId, away: campeaoNacionalId, homeScore:0, awayScore:0, soWinner:null, played:false, date: new Date(datas.andata) },
      leg2: { home: campeaoNacionalId, away: adversarioId, homeScore:0, awayScore:0, soWinner:null, played:false, date: new Date(datas.ritorno) },
      financasAtribuidas: false, prestigioAtribuido: false,
    };
    const dobradinhaTxt = qualificacao.substituicaoDuploVencedor
      ? " (o campeão nacional também venceu a Coppa Italia na época anterior — joga em seu lugar o finalista vencido)"
      : "";
    pushNews(state.currentDate, `Supercoppa Italiana ${seasonLabel(state.season)}: ${teamLinkHtml(campeaoNacionalId)} defronta ${teamLinkHtml(adversarioId)}, a duas mãos (${fmtDateLong(new Date(datas.andata))} e ${fmtDateLong(new Date(datas.ritorno))})${dobradinhaTxt}.`, "sistema", "Supercoppa Italiana", {autoAdvanceStop:true});
  }
  function supercoppaItalianaAwardOutcome(jogo){
    if(!jogo || !jogo.concluida || !jogo.vencedor) return;
    const vencedorId = jogo.vencedor, finalistaId = vencedorId===jogo.campeaoNacionalId ? jogo.adversarioId : jogo.campeaoNacionalId;
    const vencedorTeam = state.teams[vencedorId], finalistaTeam = state.teams[finalistaId];
    if(vencedorTeam && !jogo.prestigioAtribuido){
      awardClubTitle(vencedorId, "supercoppa-italiana", `Supercoppa Italiana ${jogo.seasonLabel||seasonLabel(jogo.epoca)}`);
      vencedorTeam.reputacaoPontos = clamp((vencedorTeam.reputacaoPontos!=null?vencedorTeam.reputacaoPontos:normalizeClubReputation(vencedorTeam.reputacao, vencedorTeam)) + SUPERCOPPA_ITALIANA_PRESTIGE_WINNER, 5, 99);
      vencedorTeam.reputacao = reputationFromPoints(vencedorTeam.reputacaoPontos);
      jogo.prestigioAtribuido = true;
    }
    if(!jogo.financasAtribuidas){
      if(vencedorTeam) addFinanceMovement(vencedorTeam, "receita", "Prémio de competição", `Supercoppa Italiana ${jogo.seasonLabel||seasonLabel(jogo.epoca)} — vencedor`, SUPERCOPPA_ITALIANA_PRIZE_WINNER, state.currentDate);
      if(finalistaTeam) addFinanceMovement(finalistaTeam, "receita", "Prémio de competição", `Supercoppa Italiana ${jogo.seasonLabel||seasonLabel(jogo.epoca)} — finalista`, SUPERCOPPA_ITALIANA_PRIZE_RUNNERUP, state.currentDate);
      jogo.financasAtribuidas = true;
    }
  }
  // Decisão pelo agregado das duas mãos (golos do campeão nacional vs. golos do adversário, em
  // qualquer dos dois jogos); se o agregado empatar, decide o desempate da 2ª mão (grandes
  // penalidades, sempre forçadas nessa mão — ver simulateMatchToCompletion(...,true,...) abaixo).
  function recordSupercoppaItalianaLeg(legKey, hs, as, soWinner){
    const jogo = state.supercoppaItaliana && state.supercoppaItaliana.jogo;
    const leg = jogo && jogo[legKey];
    if(!leg || leg.played) return;
    leg.played = true; leg.homeScore = hs; leg.awayScore = as; leg.soWinner = soWinner||null;
    if(legKey==="leg1"){
      // Correção (pedido do utilizador, 2026-09-17: "não quero notícias individuais de
      // resultados ... ou outra competição"): só publica quando o clube do utilizador é um dos
      // dois finalistas.
      if(leg.home===state.userTeamId || leg.away===state.userTeamId){
        pushNews(state.currentDate, `Supercoppa Italiana ${jogo.seasonLabel} — 1ª mão: ${teamLinkHtml(leg.home)} ${hs}-${as} ${teamLinkHtml(leg.away)}.`, "jogo", "Supercoppa Italiana — 1ª mão");
      }
      return;
    }
    const golosCampeao = jogo.leg1.awayScore + jogo.leg2.homeScore;
    const golosAdversario = jogo.leg1.homeScore + jogo.leg2.awayScore;
    let vencedor;
    if(golosCampeao > golosAdversario) vencedor = jogo.campeaoNacionalId;
    else if(golosAdversario > golosCampeao) vencedor = jogo.adversarioId;
    else vencedor = leg.soWinner==="home" ? jogo.campeaoNacionalId : leg.soWinner==="away" ? jogo.adversarioId : null;
    // Correção (bug latente apanhado numa época completa de regressão, 2026-10-08): se o agregado
    // empata mas a 2ª mão NÃO terminou empatada (ex.: 2-1 na ida e 1-0 do outro lado na volta),
    // o motor não gera grandes penalidades (só o faz quando a própria mão acaba empatada) e
    // soWinner vem nulo — a Supercoppa ficava por concluir para sempre e a época nunca fechava.
    // Passa a decidir-se por um desempate sorteado.
    if(!vencedor) vencedor = Math.random()<0.5 ? jogo.campeaoNacionalId : jogo.adversarioId;
    if(!vencedor){ console.error("Supercoppa Italiana: eliminatória terminou sem vencedor definido no agregado.", jogo); return; }
    jogo.vencedor = vencedor; jogo.concluida = true;
    supercoppaItalianaAwardOutcome(jogo);
    const finalistaId = vencedor===jogo.campeaoNacionalId ? jogo.adversarioId : jogo.campeaoNacionalId;
    pushNews(state.currentDate, `🏆 ${teamLinkHtml(vencedor)} venceu a Supercoppa Italiana ${jogo.seasonLabel} (agregado ${golosCampeao}-${golosAdversario}${vencedor===jogo.campeaoNacionalId?"":" a favor do adversário"}), frente a ${teamLinkHtml(finalistaId)}.`, "sistema", "Supercoppa Italiana — Resultado", {autoAdvanceStop:true});
    if(!Array.isArray(state.supercoppaItaliana.historico)) state.supercoppaItaliana.historico = [];
    if(!state.supercoppaItaliana.historico.some(e=>e.epoca===jogo.epoca)) state.supercoppaItaliana.historico.push({ ...jogo });
  }
  function processSupercoppaItalianaForCurrentDate(){
    const jogo = state.supercoppaItaliana && state.supercoppaItaliana.jogo;
    if(!jogo || jogo.concluida) return false;
    const legKey = !jogo.leg1.played ? "leg1" : !jogo.leg2.played ? "leg2" : null;
    if(!legKey) return false;
    const leg = jogo[legKey];
    if(!leg.date || new Date(leg.date) > state.currentDate) return false;
    const involvesUser = leg.home===state.userTeamId || leg.away===state.userTeamId;
    if(!involvesUser){
      // 1ª mão: resultado normal (empate possível, decide-se só no agregado da 2ª mão). 2ª mão:
      // isPlayoff=true força um vencedor de jogo (grandes penalidades se necessário) — usado só
      // como desempate de recurso, se o agregado das duas mãos ainda assim ficar empatado.
      const res = simulateMatchToCompletion(leg.home, leg.away, legKey==="leg2", false, "supercoppa-italiana");
      recordSupercoppaItalianaLeg(legKey, res.home, res.away, res.soWinner);
      return true;
    }
    if(state.matchDayReady) return false;
    const oppId = leg.home===state.userTeamId ? leg.away : leg.home;
    state.pendingProvisional = { mine: ensureMinimumSquad(myTeam()), opp: ensureMinimumSquad(state.teams[oppId]) };
    state.pendingFixture = leg; state.pendingSupercoppaItalianaLeg = legKey;
    state.pendingSuspensionServing = { home: getSuspendedIds(leg.home), away: getSuspendedIds(leg.away) };
    generatePreGameReport(leg, `Supercoppa Italiana — ${legKey==="leg1"?"1ª mão":"2ª mão"}`, null);
    state.matchDayReady = true;
    return true;
  }
  // Serialização/desserialização para guardar/carregar (11-guardar-carregar.js) — mesmo padrão
  // usado pela Taça de Portugal/Elite Cup (datas em ISO string na gravação, Date ao carregar).
  function supercopaEspanaSerializeEdition(e){
    if(!e) return null;
    const iso = v => v ? new Date(v).toISOString() : null;
    const jogos = {};
    Object.keys(e.jogos||{}).forEach(fase=>{ jogos[fase] = (e.jogos[fase]||[]).map(j=>({...j, date: iso(j.date)})); });
    return { ...e, jogos, datas: e.datas ? { semifinal: iso(e.datas.semifinal), final: iso(e.datas.final) } : null };
  }
  function supercopaEspanaDeserializeEdition(e){
    if(!e) return null;
    const dedate = v => v ? new Date(v) : null;
    const jogos = {};
    Object.keys(e.jogos||{}).forEach(fase=>{ jogos[fase] = (e.jogos[fase]||[]).map(j=>({...j, date: dedate(j.date)})); });
    return { ...e, jogos, datas: e.datas ? { semifinal: dedate(e.datas.semifinal), final: dedate(e.datas.final) } : null };
  }
  function supercoppaItalianaSerializeJogo(jogo){
    if(!jogo) return null;
    const iso = v => v ? new Date(v).toISOString() : null;
    return { ...jogo, leg1: {...jogo.leg1, date: iso(jogo.leg1.date)}, leg2: {...jogo.leg2, date: iso(jogo.leg2.date)} };
  }
  function supercoppaItalianaDeserializeJogo(jogo){
    if(!jogo) return null;
    const dedate = v => v ? new Date(v) : null;
    return { ...jogo, leg1: {...jogo.leg1, date: dedate(jogo.leg1.date)}, leg2: {...jogo.leg2, date: dedate(jogo.leg2.date)} };
  }
